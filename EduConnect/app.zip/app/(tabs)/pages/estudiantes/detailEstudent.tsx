import React from "react";
import { View, Text, Image, Pressable, StyleSheet, ScrollView } from "react-native";

/**
 * index.tsx — React Native (TSX)
 * Pantalla: Año Lectivo (UI como el mock HTML adjunto)
 *
 * Reglas del usuario:
 * - NO inventar notas, promedios ni métricas académicas.
 * - Datos QUEMADOS del estudiante:
 *   nombre: "María Fernanda López"
 *   id: "0923145789" (no se muestra porque el mock no lo usa)
 *   curso consolidado: "8vo EGB paralelo B"
 */

const STUDENT = {
  nombre: "María Fernanda López",
  id: "0923145789",
  curso: "8vo EGB paralelo B",
  avatar:
    "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=400&auto=format&fit=crop", // imagen demo
};

const PERIODOS = {
  actual: {
    titulo: "Año Lectivo 2024-2025",
    rango: "Septiembre 2024 - Junio 2025",
  },
  anteriores: [
    { grado: "8vo EGB paralelo B", titulo: "Año Lectivo 2023-2024", rango: "Septiembre 2023 - Junio 2024" },
    { grado: "8vo EGB paralelo B", titulo: "Año Lectivo 2022-2023", rango: "Septiembre 2022 - Junio 2023" },
  ],
};

export default function AcademicYearScreen() {
  const onBack = () => {};
  const onVerCursos = () => {};
  const onVerDetalles = (titulo: string) => {};

  return (
    <View style={[styles.container]}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={styles.iconText}>←</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Año Lectivo</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* Perfil */}
        <View style={styles.center}>
          <Image source={{ uri: STUDENT.avatar }} style={styles.avatar} />
          <Text style={styles.name}>{STUDENT.nombre}</Text>
          <Text style={styles.grade}>{STUDENT.curso}</Text>
        </View>

        {/* Año lectivo actual */}
        <Text style={styles.sectionTitle}>Año Lectivo Actual</Text>
        <View style={styles.card}>
          <View style={{ gap: 8 }}>
            <Text style={styles.gradePill}>{STUDENT.curso}</Text>
            <Text style={styles.cardTitle}>{PERIODOS.actual.titulo}</Text>
            <View style={styles.row}> 
              <Text style={styles.rowIcon}>📅</Text>
              <Text style={styles.rowText}>{PERIODOS.actual.rango}</Text>
            </View>
            <Pressable onPress={onVerCursos} style={styles.primaryBtn}>
              <Text style={styles.primaryBtnText}>Ver Cursos →</Text>
            </Pressable>
          </View>
        </View>

        {/* Años anteriores */}
        <Text style={styles.sectionTitle}>Años Lectivos Anteriores</Text>
        <View style={{ gap: 12 }}>
          {PERIODOS.anteriores.map((p, idx) => (
            <View key={idx} style={styles.cardSmall}>
              <View style={{ gap: 6 }}>
                <Text style={styles.prevGrade}>{p.grado}</Text>
                <View style={styles.prevHeader}>
                  <Text style={styles.prevTitle}>{p.titulo}</Text>
                  <Pressable onPress={() => onVerDetalles(p.titulo)} style={styles.ghostBtn}>
                    <Text style={styles.ghostBtnText}>Ver Detalles</Text>
                  </Pressable>
                </View>
                <View style={styles.row}> 
                  <Text style={styles.rowIcon}>📅</Text>
                  <Text style={styles.rowText}>{p.rango}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F8FAFC" },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
  },
  iconBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  iconText: { fontSize: 18, color: "#0F172A" },
  headerTitle: { color: "#0F172A", fontSize: 18, fontWeight: "800" },

  center: { alignItems: "center", gap: 6, marginBottom: 12 },
  avatar: { width: 96, height: 96, borderRadius: 999, borderWidth: 4, borderColor: "#005A9C", marginBottom: 8 },
  name: { fontSize: 22, fontWeight: "800", color: "#0F172A" },
  grade: { fontSize: 14, fontWeight: "700", color: "#16A34A" },

  sectionTitle: { fontSize: 18, fontWeight: "800", color: "#0F172A", marginTop: 16, marginBottom: 8 },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    padding: 16,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  gradePill: {
    alignSelf: "flex-start",
    color: "#16A34A",
    fontWeight: "800",
    fontSize: 12,
    backgroundColor: "#F0FDF4",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  cardTitle: { fontSize: 22, fontWeight: "800", color: "#0F172A", marginTop: 4 },

  row: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 6 },
  rowIcon: { fontSize: 14, color: "#64748B" },
  rowText: { fontSize: 14, color: "#475569" },

  primaryBtn: { marginTop: 10, backgroundColor: "#005A9C", height: 48, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  primaryBtnText: { color: "#FFFFFF", fontWeight: "800", fontSize: 16 },

  cardSmall: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    padding: 12,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  prevGrade: { color: "#64748B", fontSize: 12, fontWeight: "800" },
  prevHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  prevTitle: { fontSize: 16, fontWeight: "800", color: "#0F172A" },
  ghostBtn: { backgroundColor: "#E6F0FA", borderRadius: 10, paddingHorizontal: 12, height: 40, alignItems: "center", justifyContent: "center" },
  ghostBtnText: { color: "#005A9C", fontWeight: "800", fontSize: 12 },
});