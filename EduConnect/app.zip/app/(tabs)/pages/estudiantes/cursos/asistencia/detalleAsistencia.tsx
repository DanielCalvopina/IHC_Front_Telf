import React from "react";
import { View, Text, Pressable, StyleSheet, ScrollView } from "react-native";
// Si usas Expo Router, puedes descomentar estas líneas para manejar back por router
// import { useRouter, useLocalSearchParams } from "expo-router";

type Props = {
  // Si no usas Expo Router, puedes inyectar props opcionales:
  statusLabel?: string;
  dateLabel?: string;
  subjectName?: string;
  teacherName?: string;
  onBack?: () => void;
  onJustify?: () => void;
};

export default function DetalleAsistencia(props: Props) {
  // const router = useRouter();
  // const params = useLocalSearchParams();

  const {
    statusLabel = "Ausencia Injustificada",
    dateLabel = "Lunes, 23 de Octubre de 2023",
    subjectName = "Ciencias Naturales",
    teacherName = "Ana Martínez",
    onBack,
    onJustify,
  } = props;

  const handleBack = () => {
    if (onBack) return onBack();
    // Si usas Expo Router, descomenta:
    // router.back();
  };

  const handleJustify = () => {
    if (onJustify) return onJustify();
    // Placeholder: aquí abrirías tu formulario de justificación
    // router.push("/(tabs)/pages/estudiantes/cursos/asistencia/justificar");
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={handleBack} style={styles.iconBtn}>
          <Text style={styles.iconText}>←</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Detalle de Inasistencia</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* Card superior */}
        <View style={styles.absTopCard}>
          <View style={styles.absTopRow}>
            <View style={styles.absenceIconBig}>
              <Text style={styles.absenceIconEmoji}>🗓️</Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.absTopTitle}>{statusLabel}</Text>
              <Text style={styles.absTopDate}>{dateLabel}</Text>
            </View>
          </View>

          <View style={{ padding: 16 }}>
            <View style={styles.absLineRow}>
              <Text style={styles.absLineBullet}>🎓</Text>
              <Text style={styles.absLineLabel}>Materia: </Text>
              <Text style={styles.absLineValue}>{subjectName}</Text>
            </View>
            <View style={styles.absLineRow}>
              <Text style={styles.absLineBullet}>👩‍🏫</Text>
              <Text style={styles.absLineLabel}>Profesor: </Text>
              <Text style={styles.absLineValue}>{teacherName}</Text>
            </View>
          </View>
        </View>

        {/* Motivo */}
        <Text style={styles.blockTitle}>Motivo de la inasistencia</Text>
        <Text style={styles.blockText}>
          No se ha proporcionado un motivo para esta inasistencia. Si la falta
          fue por un motivo justificado, por favor comuníquese con el profesor.
        </Text>

        {/* Comentarios del profesor */}
        <Text style={styles.blockTitle}>Comentarios del Profesor</Text>
        <Text style={styles.blockText}>
          El estudiante no se presentó a la clase y no se recibió ninguna
          notificación previa de los padres o tutores. Se recomienda ponerse en
          contacto para regularizar la situación.
        </Text>
      </ScrollView>

      {/* Botón inferior (sin “Contactar Profesor”) */}
      <View style={{ padding: 16 }}>
        <Pressable onPress={handleJustify} style={styles.primaryBtn}>
          <Text style={styles.primaryBtnText}>✏️  Justificar Falta</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F4F4F4" },

  header: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
  },
  iconBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  iconText: { fontSize: 18, color: "#0F172A" },
  headerTitle: { color: "#0F172A", fontSize: 18, fontWeight: "800" },

  // Card superior
  absTopCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    shadowColor: "#000",
    shadowOpacity: 0.07,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
    overflow: "hidden",
  },
  absTopRow: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#EAECEF",
  },
  absenceIconBig: {
    width: 48,
    height: 48,
    borderRadius: 999,
    backgroundColor: "#4A90E2" + "33",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 12,
  },
  absenceIconEmoji: { fontSize: 24, color: "#4A90E2" },
  absTopTitle: { color: "#0F172A", fontSize: 16, fontWeight: "800" },
  absTopDate: { color: "#6B7280", fontSize: 14, marginTop: 2 },

  absLineRow: { flexDirection: "row", alignItems: "center", marginTop: 10 },
  absLineBullet: { fontSize: 14, marginRight: 6, color: "#6B7280" },
  absLineLabel: { color: "#6B7280", fontSize: 14, marginRight: 4 },
  absLineValue: { color: "#0F172A", fontSize: 14, fontWeight: "800" },

  blockTitle: { color: "#0F172A", fontSize: 16, fontWeight: "800", marginTop: 16 },
  blockText: { color: "#374151", fontSize: 14, marginTop: 6 },

  primaryBtn: {
    backgroundColor: "#4A90E2",
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  primaryBtnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "800" },
});
