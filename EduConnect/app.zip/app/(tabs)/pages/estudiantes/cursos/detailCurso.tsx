import React, { useMemo, useState } from "react";
import { View, Text, Image, Pressable, StyleSheet, ScrollView } from "react-native";

/**
 * index.tsx — React Native (TSX)
 * Pantallas: Año Lectivo → Cursos → Detalle de Curso
 *
 * Reglas del usuario:
 * - No inventar información fuera del mock.
 * - Datos QUEMADOS del estudiante:
 *   nombre: "María Fernanda López"
 *   id: "0923145789" (guardado, no mostrado)
 *   curso consolidado: "8vo EGB paralelo B"
 * - Cursos: Matemáticas, Ciencias Naturales, Historia.
 * - Detalle del curso basado en el mock de "Matemáticas Avanzadas" (profesor, botón de notificaciones, tabs y calificaciones con promedios 8.5 / 8.2 / 8.8).
 */

const STUDENT = {
  nombre: "María Fernanda López",
  id: "0923145789",
  curso: "8vo EGB paralelo B",
  avatar:
    "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=400&auto=format&fit=crop",
};

const PERIODOS = {
  actual: { titulo: "Año Lectivo 2024-2025", rango: "Septiembre 2024 - Junio 2025" },
  anteriores: [
    { grado: "8vo EGB paralelo B", titulo: "Año Lectivo 2023-2024", rango: "Septiembre 2023 - Junio 2024" },
    { grado: "8vo EGB paralelo B", titulo: "Año Lectivo 2022-2023", rango: "Septiembre 2022 - Junio 2023" },
  ],
};

const CURSOS = [
  { key: "mat", nombre: "Matemáticas", icono: "🧮", detalleTitulo: "Matemáticas Avanzadas" },
  { key: "nat", nombre: "Ciencias Naturales", icono: "🧪", detalleTitulo: "Ciencias Naturales" },
  { key: "his", nombre: "Historia", icono: "🌍", detalleTitulo: "Historia" },
];

/*************************
 * Pantalla: Año Lectivo
 *************************/
function AcademicYearScreen({ onBack, onVerCursos }: { onBack: () => void; onVerCursos: () => void }) {
  return (
    <View style={[styles.container]}>
      {/* Header */}
      <View style={styles.header}> 
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={styles.iconText}>←</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Año Lectivo</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* Perfil */}
        <View style={styles.center}>
          <Image source={{ uri: STUDENT.avatar }} style={styles.avatar} />
          <Text style={styles.name}>{STUDENT.nombre}</Text>
          <Text style={styles.grade}>{STUDENT.curso}</Text>
        </View>

        {/* Año lectivo actual */}
        <Text style={styles.sectionTitle}>Año Lectivo Actual</Text>
        <View style={styles.card}>
          <View style={{ gap: 8 }}>
            <Text style={styles.gradePill}>{STUDENT.curso}</Text>
            <Text style={styles.cardTitle}>{PERIODOS.actual.titulo}</Text>
            <View style={styles.row}> 
              <Text style={styles.rowIcon}>📅</Text>
              <Text style={styles.rowText}>{PERIODOS.actual.rango}</Text>
            </View>
            <Pressable onPress={onVerCursos} style={styles.primaryBtn}>
              <Text style={styles.primaryBtnText}>Ver Cursos →</Text>
            </Pressable>
          </View>
        </View>

        {/* Años anteriores */}
        <Text style={styles.sectionTitle}>Años Lectivos Anteriores</Text>
        <View style={{ gap: 12 }}>
          {PERIODOS.anteriores.map((p, idx) => (
            <View key={idx} style={styles.cardSmall}>
              <View style={{ gap: 6 }}>
                <Text style={styles.prevGrade}>{p.grado}</Text>
                <View style={styles.prevHeader}>
                  <Text style={styles.prevTitle}>{p.titulo}</Text>
                  <Pressable onPress={() => {}} style={styles.ghostBtn}>
                    <Text style={styles.ghostBtnText}>Ver Detalles</Text>
                  </Pressable>
                </View>
                <View style={styles.row}> 
                  <Text style={styles.rowIcon}>📅</Text>
                  <Text style={styles.rowText}>{p.rango}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

/*************************
 * Pantalla: Cursos del Estudiante
 *************************/
function CoursesScreen({ onBack, onOpenCourse }: { onBack: () => void; onOpenCourse: (key: string) => void }) {
  const [year, setYear] = useState(2024);
  const years = [2024, 2023, 2022];
  const nextYear = () => {
    const idx = years.indexOf(year);
    const next = years[(idx + 1) % years.length];
    setYear(next);
  };

  const cursosDelAnio = useMemo(() => CURSOS, [year]); // datos quemados, mismos cursos

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: "#0D47A1" }]}> 
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={[styles.iconText, { color: "#fff" }]}>←</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: "#fff" }]}>Cursos de {STUDENT.nombre.split(" ")[0]}</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* Selector de año lectivo (simple) */}
        <View style={{ marginBottom: 12 }}>
          <Text style={{ color: "#0F172A", fontWeight: "600", marginBottom: 6 }}>Año lectivo</Text>
          <Pressable onPress={nextYear} style={styles.select}>
            <Text style={styles.selectText}>{year}</Text>
            <Text style={styles.selectChevron}>⌄</Text>
          </Pressable>
        </View>

        {/* Lista de cursos */}
        <View style={{ gap: 12 }}>
          {cursosDelAnio.map((c) => (
            <View key={c.key} style={styles.courseCard}>
              <View style={styles.courseLeft}>
                <View style={styles.courseIconWrap}><Text style={styles.courseIcon}>{c.icono}</Text></View>
                <Text style={styles.courseTitle}>{c.nombre}</Text>
              </View>
              <Pressable onPress={() => onOpenCourse(c.key)} style={styles.courseAction}>
                <Text style={{ color: "#fff", fontWeight: "800" }}>›</Text>
              </Pressable>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

/*************************
 * Pantalla: Detalle de Curso (basado en mock)
 *************************/
function CourseDetailScreen({ title, onBack }: { title: string; onBack: () => void }) {
  // Datos quemados del profesor (según mock)
  const teacher = {
    nombre: "Carlos Rodríguez",
    email: "crodriguez@school.com",
    avatar:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuC_Z-sWzZRR7WcDyLWDPx0Fft3e6HZKTlo7VjFoiK_UuIhIZLWB41z6FIQcN6gr40RJxM_gIuNfxpaNyt0T6wP86991reLBbPRqrm8NLOGoX80_gJTmUFVGQDNAy-0G58OFF3ue0CzgSEebTXhaVQgslTW6qT7_-Hz1EUc0i8en9SZnUCKLBKIWZ9s6m2NGcVNbn9b4Ml9dHpBqdTvXfjId4GmHvLWrBB7DoKHjxnAZaV4Rv5iWbU0v_HEaJNXp_FzHAPAxzkwt_wI",
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: "#fff" }]}> 
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={[styles.iconText]}>←</Text>
        </Pressable>
        <Text style={[styles.headerTitle]}>{title}</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingVertical: 12 }}>
        {/* Tarjeta Profesor */}
        <View style={{ paddingHorizontal: 16 }}>
          <View style={styles.teacherCard}>
            <View style={{ flex: 2, gap: 2 }}>
              <Text style={styles.teacherLabel}>Profesor</Text>
              <Text style={styles.teacherName}>{teacher.nombre}</Text>
              <Text style={styles.teacherEmail}>{teacher.email}</Text>
            </View>
            <Image source={{ uri: teacher.avatar }} style={styles.teacherAvatar} />
          </View>
        </View>

        {/* Contactar */}
        <View style={{ paddingHorizontal: 16, marginTop: 8 }}>
          <View style={styles.contactCard}>
            <Text style={styles.contactTitle}>Contactar al profesor</Text>
            <Text style={styles.contactDesc}>Consulta las notificaciones del profesor para estar al día.</Text>
            <Pressable onPress={() => {}} style={styles.notifyBtn}>
              <Text style={styles.notifyBtnText}>🔔  Ver Notificaciones</Text>
            </Pressable>
          </View>
        </View>

        {/* Tabs (Calificaciones activo, Asistencia inactivo) */}
        <View style={styles.tabsWrap}>
          <View style={[styles.tabItem, styles.tabItemActive]}>
            <Text style={[styles.tabText, styles.tabTextActive]}>Calificaciones</Text>
          </View>
          <View style={styles.tabItem}>
            <Text style={styles.tabText}>Asistencia</Text>
          </View>
        </View>

        {/* Calificaciones */}
        <View style={{ paddingHorizontal: 16 }}>
          <View style={styles.gradesCard}>
            <View style={styles.gradesHeader}>
              <Text style={styles.gradesTitle}>Calificaciones</Text>
              <Text style={styles.gradesAvg}>Promedio: 8.5</Text>
            </View>
            <View style={{ gap: 10 }}>
              <Pressable style={styles.gradeRow}>
                <View>
                  <Text style={styles.gradeRowTitle}>Primer Semestre</Text>
                  <Text style={styles.gradeRowSub}>Promedio: 8.2</Text>
                </View>
                <Text style={styles.arrow}>{"›"}</Text>
              </Pressable>
              <Pressable style={styles.gradeRow}>
                <View>
                  <Text style={styles.gradeRowTitle}>Segundo Semestre</Text>
                  <Text style={styles.gradeRowSub}>Promedio: 8.8</Text>
                </View>
                <Text style={styles.arrow}>{"›"}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

/*************************
 * App principal (navegación en memoria)
 *************************/
export default function App() {
  const [screen, setScreen] = useState<"year" | "courses" | "courseDetail">("year");
  const [courseTitle, setCourseTitle] = useState<string>("Matemáticas Avanzadas");

  return (
    <View style={styles.container}>
      {screen === "year" && (
        <AcademicYearScreen onBack={() => {}} onVerCursos={() => setScreen("courses")} />
      )}
      {screen === "courses" && (
        <CoursesScreen
          onBack={() => setScreen("year")}
          onOpenCourse={(key) => {
            const c = CURSOS.find((x) => x.key === key);
            setCourseTitle(c?.detalleTitulo ?? c?.nombre ?? "Curso");
            setScreen("courseDetail");
          }}
        />
      )}
      {screen === "courseDetail" && (
        <CourseDetailScreen title={courseTitle} onBack={() => setScreen("courses")} />
      )}
    </View>
  );
}

/*************************
 * Estilos
 *************************/
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F6F7F8" },
  header: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "#FFFFFF",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
  },
  iconBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  iconText: { fontSize: 18, color: "#0F172A" },
  headerTitle: { color: "#0F172A", fontSize: 18, fontWeight: "800" },

  center: { alignItems: "center", gap: 6, marginBottom: 12 },
  avatar: { width: 96, height: 96, borderRadius: 999, borderWidth: 4, borderColor: "#005A9C", marginBottom: 8 },
  name: { fontSize: 22, fontWeight: "800", color: "#0F172A" },
  grade: { fontSize: 14, fontWeight: "700", color: "#16A34A" },

  sectionTitle: { fontSize: 18, fontWeight: "800", color: "#0F172A", marginTop: 16, marginBottom: 8 },

  card: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    padding: 16,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  gradePill: {
    alignSelf: "flex-start",
    color: "#16A34A",
    fontWeight: "800",
    fontSize: 12,
    backgroundColor: "#F0FDF4",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  cardTitle: { fontSize: 22, fontWeight: "800", color: "#0F172A", marginTop: 4 },

  row: { flexDirection: "row", alignItems: "center", gap: 8, marginTop: 6 },
  rowIcon: { fontSize: 14, color: "#64748B" },
  rowText: { fontSize: 14, color: "#475569" },

  primaryBtn: { marginTop: 10, backgroundColor: "#005A9C", height: 48, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  primaryBtnText: { color: "#FFFFFF", fontWeight: "800", fontSize: 16 },

  cardSmall: {
    backgroundColor: "#FFFFFF",
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    padding: 12,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  prevGrade: { color: "#64748B", fontSize: 12, fontWeight: "800" },
  prevHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  prevTitle: { fontSize: 16, fontWeight: "800", color: "#0F172A" },
  ghostBtn: { backgroundColor: "#E6F0FA", borderRadius: 10, paddingHorizontal: 12, height: 40, alignItems: "center", justifyContent: "center" },
  ghostBtnText: { color: "#005A9C", fontWeight: "800", fontSize: 12 },

  // Cursos
  select: { backgroundColor: "#fff", borderRadius: 12, borderWidth: 1, borderColor: "#CBD5E1", height: 48, paddingHorizontal: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  selectText: { color: "#0F172A", fontSize: 16, fontWeight: "700" },
  selectChevron: { color: "#64748B", fontSize: 18 },

  courseCard: { backgroundColor: "#FFFFFF", borderRadius: 18, shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 8, shadowOffset: { width: 0, height: 4 }, borderWidth: 1, borderColor: "#E2E8F0", padding: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  courseLeft: { flexDirection: "row", alignItems: "center", gap: 12 },
  courseIconWrap: { width: 48, height: 48, borderRadius: 999, backgroundColor: "#4CAF50" + "33", alignItems: "center", justifyContent: "center" },
  courseIcon: { fontSize: 22 },
  courseTitle: { fontSize: 16, fontWeight: "800", color: "#0F172A" },
  courseAction: { backgroundColor: "#0D47A1", width: 40, height: 40, borderRadius: 999, alignItems: "center", justifyContent: "center" },

  // Detalle curso
  teacherCard: { backgroundColor: "#FFFFFF", marginTop: 8, borderRadius: 16, borderWidth: 1, borderColor: "#E2E8F0", padding: 16, flexDirection: "row", alignItems: "center", gap: 12, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 6, shadowOffset: { width: 0, height: 3 } },
  teacherLabel: { color: "#005A9C", fontSize: 13, fontWeight: "700" },
  teacherName: { color: "#0F172A", fontSize: 16, fontWeight: "800" },
  teacherEmail: { color: "#64748B", fontSize: 13 },
  teacherAvatar: { width: 96, height: 96, borderRadius: 999, flex: 1 },

  contactCard: { backgroundColor: "#FFFFFF", marginTop: 12, borderRadius: 16, borderWidth: 1, borderColor: "#E2E8F0", padding: 16, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 6, shadowOffset: { width: 0, height: 3 } },
  contactTitle: { color: "#0F172A", fontSize: 16, fontWeight: "800" },
  contactDesc: { color: "#475569", fontSize: 14, marginTop: 2 },
  notifyBtn: { backgroundColor: "#005A9C", height: 48, borderRadius: 12, alignItems: "center", justifyContent: "center", marginTop: 12 },
  notifyBtnText: { color: "#fff", fontSize: 16, fontWeight: "800" },

  tabsWrap: { flexDirection: "row", borderBottomWidth: 1, borderBottomColor: "#E2E8F0", marginTop: 12, paddingHorizontal: 16 },
  tabItem: { flex: 1, alignItems: "center", paddingVertical: 12, borderBottomWidth: 3, borderBottomColor: "transparent" },
  tabItemActive: { borderBottomColor: "#005A9C" },
  tabText: { color: "#64748B", fontSize: 13, fontWeight: "800" },
  tabTextActive: { color: "#0F172A" },

  gradesCard: { backgroundColor: "#FFFFFF", marginTop: 12, borderRadius: 16, borderWidth: 1, borderColor: "#E2E8F0", padding: 16, gap: 12, shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 6, shadowOffset: { width: 0, height: 3 } },
  gradesHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  gradesTitle: { color: "#0F172A", fontSize: 18, fontWeight: "800" },
  gradesAvg: { color: "#16A34A", fontSize: 18, fontWeight: "800" },
  gradeRow: { borderWidth: 1, borderColor: "#E2E8F0", borderRadius: 12, padding: 14, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  gradeRowTitle: { color: "#0F172A", fontSize: 16, fontWeight: "800" },
  gradeRowSub: { color: "#64748B", fontSize: 13, marginTop: 2 },
  arrow: { color: "#005A9C", fontSize: 22, fontWeight: "900" },
});