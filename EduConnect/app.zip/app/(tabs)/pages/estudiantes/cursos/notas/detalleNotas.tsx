import React, { useState } from "react";
import { View, Text, ScrollView, StyleSheet, Pressable } from "react-native";

type Props = {
  subjectName?: string;
  studentName?: string;
  onBack?: () => void;
};

export default function DetalleNotas({
  subjectName = "Matemáticas",
  studentName = "Juan Pérez",
  onBack,
}: Props) {
  const [semester, setSemester] = useState<1 | 2>(1);
  const [unit, setUnit] = useState<1 | 2 | 3 | 4>(1);

  const promedioUnidad = 9.5;
  const items = [
    { icon: "✅", title: "Examen Parcial 1", date: "15/03/2024", grade: 9.5, kind: "exam" },
    { icon: "📄", title: "Tarea de Investigación", date: "22/03/2024", grade: 8.0, kind: "task" },
    { icon: "✅", title: "Exposición Oral", date: "05/04/2024", grade: 7.2, kind: "exam" },
    { icon: "📄", title: "Examen Final", date: "20/05/2024", grade: 8.8, kind: "task" },
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: "#F6F7F8" }]}>
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={[styles.iconText, { color: "#374151" }]}>←</Text>
        </Pressable>
        <Text style={[styles.headerTitle, { color: "#111827" }]}>Detalle de Notas</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 20 }}>
        {/* Título */}
        <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
          <Text style={{ fontSize: 22, fontWeight: "800", color: "#111827" }}>{subjectName}</Text>
          <Text style={{ color: "#6B7280", marginTop: 2 }}>{studentName}</Text>
        </View>

        {/* Semestres */}
        <View style={{ paddingHorizontal: 16, marginTop: 12 }}>
          <View style={styles.segmentWrap}>
            <Pressable
              onPress={() => setSemester(1)}
              style={[styles.segmentBtn, semester === 1 && styles.segmentBtnActive]}
            >
              <Text style={[styles.segmentText, semester === 1 && styles.segmentTextActive]}>Semestre 1</Text>
            </Pressable>
            <Pressable
              onPress={() => setSemester(2)}
              style={[styles.segmentBtn, semester === 2 && styles.segmentBtnActive]}
            >
              <Text style={[styles.segmentText, semester === 2 && styles.segmentTextActive]}>Semestre 2</Text>
            </Pressable>
          </View>
        </View>

        {/* Unidades */}
        <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
            {[1, 2, 3, 4].map((u) => (
              <Pressable
                key={u}
                onPress={() => setUnit(u as 1 | 2 | 3 | 4)}
                style={[styles.unitChip, unit === u ? styles.unitChipActive : styles.unitChipInactive]}
              >
                <Text
                  style={[
                    styles.unitChipText,
                    unit === u ? styles.unitChipTextActive : styles.unitChipTextInactive,
                  ]}
                >
                  Unidad {u}
                </Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>

        {/* Promedio */}
        <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
          <View style={styles.avgCard}>
            <Text style={styles.avgLabel}>Promedio Unidad {unit}</Text>
            <Text style={styles.avgValue}>{promedioUnidad.toFixed(1)}</Text>
          </View>
        </View>

        {/* Progreso */}
        <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
          <Text style={{ fontSize: 18, fontWeight: "700", color: "#111827" }}>
            Progreso Unidad {unit}
          </Text>
        </View>
        <View style={{ padding: 16 }}>
          <View style={styles.chartBox}>
            <View style={styles.chartBars}>
              <View style={styles.chartBarCol}>
                <View style={[styles.chartBar, { height: "95%" }]} />
                <Text style={styles.chartLabel}>Ex. 1</Text>
              </View>
              <View style={styles.chartBarCol}>
                <View style={[styles.chartBarAlt, { height: "80%" }]} />
                <Text style={styles.chartLabel}>Tarea 1</Text>
              </View>
              <View style={styles.chartBarCol}>
                <View style={[styles.chartBar, { height: "72%" }]} />
                <Text style={styles.chartLabel}>Expo.</Text>
              </View>
              <View style={styles.chartBarCol}>
                <View style={[styles.chartBarAlt, { height: "88%" }]} />
                <Text style={styles.chartLabel}>Parcial</Text>
              </View>
            </View>
            <View style={styles.chartAxis} />
            <View style={styles.chartTicks}>
              <Text style={styles.chartTickText}>10</Text>
              <Text style={styles.chartTickText}>5</Text>
              <Text style={styles.chartTickText}>0</Text>
            </View>
          </View>
        </View>

        {/* Calificaciones */}
        <View style={{ paddingHorizontal: 16, paddingTop: 6 }}>
          <Text style={{ fontSize: 18, fontWeight: "700", color: "#111827" }}>
            Calificaciones Unidad {unit}
          </Text>
        </View>

        <View style={{ marginTop: 6 }}>
          {items.map((it, idx) => (
            <View key={idx} style={styles.gradeItemRow}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={[styles.gradeIcon, it.kind === "exam" ? styles.gradeIconGreen : styles.gradeIconBlue]}>
                  <Text>{it.icon}</Text>
                </View>
                <View>
                  <Text style={styles.gradeTitle}>{it.title}</Text>
                  <Text style={styles.gradeDate}>{it.date}</Text>
                </View>
              </View>
              <Text style={styles.gradeValue}>{it.grade.toFixed(1)}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F6F7F8" },

  header: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "#E5E7EB",
  },
  iconBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  iconText: { fontSize: 18 },
  headerTitle: { fontSize: 18, fontWeight: "800" },

  /* Segment (semestres) */
  segmentWrap: { flexDirection: "row", backgroundColor: "#E5E7EB", borderRadius: 10, padding: 4 },
  segmentBtn: { flex: 1, paddingVertical: 10, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  segmentBtnActive: { backgroundColor: "#FFFFFF" },
  segmentText: { color: "#374151", fontWeight: "700" },
  segmentTextActive: { color: "#1173d4" },

  /* Chips unidades */
  unitChip: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 999 },
  unitChipActive: { backgroundColor: "#1173d4" },
  unitChipInactive: { backgroundColor: "#E5E7EB" },
  unitChipText: { fontWeight: "700" },
  unitChipTextActive: { color: "#FFFFFF" },
  unitChipTextInactive: { color: "#374151" },

  /* Promedio */
  avgCard: { backgroundColor: "#DBEAFE", borderRadius: 16, padding: 16 },
  avgLabel: { color: "#1E3A8A", fontWeight: "600" },
  avgValue: { color: "#1E3A8A", fontSize: 42, fontWeight: "800", marginTop: 4 },

  /* Chart */
  chartBox: { backgroundColor: "#FFFFFF", borderRadius: 16, padding: 12, height: 220, justifyContent: "flex-end" },
  chartBars: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between", height: 150, gap: 10 },
  chartBarCol: { flex: 1, alignItems: "center", justifyContent: "flex-end" },
  chartBar: { width: "100%", backgroundColor: "#22C55E", borderTopLeftRadius: 8, borderTopRightRadius: 8 },
  chartBarAlt: { width: "100%", backgroundColor: "#3B82F6", borderTopLeftRadius: 8, borderTopRightRadius: 8 },
  chartLabel: { marginTop: 6, fontSize: 12, color: "#6B7280" },
  chartAxis: { height: 1, backgroundColor: "#E5E7EB", marginTop: 6 },
  chartTicks: { flexDirection: "row", justifyContent: "space-between", marginTop: 6 },
  chartTickText: { fontSize: 12, color: "#9CA3AF" },

  /* Lista de calificaciones */
  gradeItemRow: {
    backgroundColor: "#F6F7F8",
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
    paddingHorizontal: 16,
    minHeight: 72,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  gradeIcon: { width: 40, height: 40, borderRadius: 999, alignItems: "center", justifyContent: "center" },
  gradeIconGreen: { backgroundColor: "#86EFAC" },
  gradeIconBlue: { backgroundColor: "#93C5FD" },
  gradeTitle: { color: "#111827", fontWeight: "600" },
  gradeDate: { color: "#6B7280", fontSize: 12, marginTop: 2 },
  gradeValue: { color: "#111827", fontSize: 18, fontWeight: "800", paddingRight: 12 },
});
