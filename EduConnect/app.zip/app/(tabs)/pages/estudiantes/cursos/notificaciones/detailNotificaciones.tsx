import React, { useState } from "react";
import { View, Text, StyleSheet, Pressable, ScrollView } from "react-native";

type Props = {
  curso?: string;
  onBack?: () => void;
  // Si luego pasas la notificación real, puedes sustituir estos campos por props
  titulo?: string;
  fechaLarga?: string;
  cuerpo?: string;
  vistoInicial?: boolean;
};

export default function DetalleNotificacion({
  curso = "Matemáticas",
  onBack,
  titulo = "Recordatorio: Examen de Álgebra",
  fechaLarga = "15 de Octubre, 2023",
  cuerpo = `Estimados padres, les recuerdo que el próximo viernes se realizará el examen de álgebra. Asegúrense de que sus hijos repasen los temas vistos en clase.`,
  vistoInicial = false,
}: Props) {
  const [visto, setVisto] = useState<boolean>(vistoInicial);

  const toggleVisto = () => setVisto((s) => !s);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.iconBtn}>
          <Text style={styles.iconText}>←</Text>
        </Pressable>
        <Text style={styles.headerTitle}>Notificaciones - {curso}</Text>
        <View style={{ width: 48 }} />
      </View>

      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {/* Tarjeta Detalle */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Text style={styles.cardTitle}>{titulo}</Text>
            <View style={styles.dateWrap}>
              <Text style={styles.dateText}>{fechaLarga}</Text>
              <View
                style={[
                  styles.dot,
                  { backgroundColor: visto ? "#CBD5E1" : "#28A745" }, // gris si visto, verde si no visto
                ]}
              />
            </View>
          </View>

          <Text style={styles.bodyText}>{cuerpo}</Text>

          {/* Estado actual */}
          <View style={styles.stateRow}>
            <Text style={styles.stateLabel}>Estado:</Text>
            <Text style={[styles.stateValue, { color: visto ? "#16A34A" : "#DC2626" }]}>
              {visto ? "Visto" : "No visto"}
            </Text>
          </View>

          {/* Botón de acción */}
          <Pressable
            onPress={toggleVisto}
            style={[styles.primaryBtn, { backgroundColor: visto ? "#64748B" : "#005A9C" }]}
          >
            <Text style={styles.primaryBtnText}>
              {visto ? "Marcar como NO visto" : "Marcar como visto"}
            </Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

/* =========================
 * Estilos
 * ========================= */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f6f7f8" },

  header: {
    height: 56,
    backgroundColor: "#005A9C",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
  },
  iconBtn: { width: 48, height: 48, alignItems: "center", justifyContent: "center" },
  iconText: { color: "#fff", fontSize: 18, fontWeight: "800" },
  headerTitle: { color: "#fff", fontSize: 16, fontWeight: "800" },

  card: {
    backgroundColor: "#fff",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#E5E7EB",
    padding: 16,
    gap: 12,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },

  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 8,
  },
  cardTitle: { color: "#003366", fontSize: 16, fontWeight: "800", flex: 1 },
  dateWrap: { flexDirection: "row", alignItems: "center", gap: 6 },
  dateText: { color: "#6C757D", fontSize: 12 },
  dot: { width: 8, height: 8, borderRadius: 999 },

  bodyText: { color: "#003366", fontSize: 14, lineHeight: 20 },

  stateRow: { flexDirection: "row", alignItems: "center", gap: 6, marginTop: 4 },
  stateLabel: { color: "#334155", fontWeight: "700" },
  stateValue: { fontWeight: "800" },

  primaryBtn: {
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 12,
  },
  primaryBtnText: { color: "#fff", fontSize: 16, fontWeight: "800" },
});
